Version loadable extensions to SQLite are found in subfolders
of this folder.
